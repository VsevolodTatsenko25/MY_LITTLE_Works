a = int(input('Введите число '))
b = int(input('Введите число '))
c = int(input('Введите число '))
d = int(input('Введите число '))
sum1 = a + b
sum2 = c + d
div = sum1 / sum2
print('Результат: ', div)