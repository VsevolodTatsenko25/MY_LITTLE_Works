a = int(input('Введите число: '))
sum = a+1
raz = a-1
print ('После числа ', a , 'идёт число ' , sum)
print ('До числа ', a , 'идёт число ' , raz)
