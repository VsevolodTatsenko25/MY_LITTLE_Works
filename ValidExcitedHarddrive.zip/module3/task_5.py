n = int(input('Введите количество минут '))
hours = n //60
minutes = n % 60
print (n, 'Минут в часах равно ', hours , 'Останется ', minutes, 'Минут')
