a = int(input('Введите первое число '))
b = int(input('Введите второе число '))
lsta = a % 100
lstb = b % 100
sum = lsta +lstb
print('Сумма: ', sum)